"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Pupp_1 = require("./lib/Pupp");
const p = new Pupp_1.Pupp();
p.grade('http://localhost:8090/tests/');
