find . -type f -name '*.js' -delete
