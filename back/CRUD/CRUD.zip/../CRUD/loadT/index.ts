import { Pupp } from "./lib/Pupp"

const p = new Pupp()

p.grade('http://localhost:8090/tests/')


