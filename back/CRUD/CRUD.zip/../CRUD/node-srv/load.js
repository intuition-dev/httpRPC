"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var bunyan = require('bunyan');
var bformat = require('bunyan-format2');
var formatOut = bformat({ outputMode: 'short' });
var log = bunyan.createLogger({ src: true, stream: formatOut, name: "load" });
const CDB_1 = require("./db/CDB");
const db = new CDB_1.CDB();
db.srchWpage('Wol', 2);
