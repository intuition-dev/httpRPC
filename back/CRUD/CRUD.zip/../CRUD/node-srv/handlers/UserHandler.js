"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const bunyan = require('bunyan');
const bformat = require('bunyan-format2');
const formatOut = bformat({ outputMode: 'short' });
const log = bunyan.createLogger({ src: true, stream: formatOut, name: "UserHandler" });
const Serv_1 = require("http-rpc/lib/Serv");
log.info('hand');
class UserHandler extends Serv_1.BaseRPCMethodHandler {
    constructor(db) {
        super(10, 9);
        this._db = db;
    }
    srch(params) {
        log.info(params);
        let srch = params.srch;
        let o = params.o;
        if ((!srch) || srch.length < 1)
            srch = 'a';
        let ret = this._db.srchWpage(srch, o);
        return ret;
    }
}
exports.UserHandler = UserHandler;
