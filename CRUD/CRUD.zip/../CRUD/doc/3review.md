
TOC of the 3 sections

https://medium.com/@cekvneich/short-review-of-basics-of-full-stack-big-data-scalability-and-clusters-of-distributed-data-bcc8e3a8abd3

## Review: The Full stack / backend programmers ( Section 3):

1. The job includes client side API. The job is not to write API, but to write good API as defined in part I.

1. Development includes an imperative language, and declarative: SQL (or the what ever the platform specific NoSQL is using)

1. Avoid adjectives and use numbers. You can get performance numbers by doing load testing.

1. The job includes a UX part: what is the response time the user will experience. An scaling for number of users. 

1. To do a distributed cluster of data systems, you must first master a single system. 


That's it for basics of full stack, big data, scalability and clusters of distributed data servers

I also plan to write part II: Advanced front end development, if you follow me on linked in or on medium, you'll know about it.

ps: https://news.ycombinator.com/item?id=11312728